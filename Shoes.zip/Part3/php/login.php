<?php
	$server = "localhost";
	$user = "60095068";
	$password = "aarizsyed";
	$database = "db60095068";

	$connection = new mysqli($server, $user, $password, $database);

	if($connection -> connect_error){
		die('Connect Error ' . $connection -> connect_error);
	}

	$username = $_GET['user_name'];
	$pass = $_GET['password'];

	$sql = "SELECT CUS_ID, CUS_NAME, CUS_PASSWORD FROM customer WHERE CUS_NAME = '$username' AND CUS_PASSWORD = '$pass'";

	$res = $connection -> query($sql);

	$row = $res -> fetch_assoc();

	if($row == NULL){
		print("<p>No record match</p>");
		print("<a href = '../html/login.html'>Click here to go back to the login page!</a>");

	}
	else{
		header('Location: products.php');
	}

?>