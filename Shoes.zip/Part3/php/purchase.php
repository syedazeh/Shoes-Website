<html>
<head>
<style type="text/css">
 table, td, th{
 	border: solid black 1px;
 	border-collapse: collapse;
 }
</style>
</head>
<body>

<?php
	$server = "localhost";
	$user = "60095068";
	$password = "aarizsyed";
	$database = "db60095068";

	$connection = new mysqli($server, $user, $password, $database);

	if($connection -> connect_error){
		die('Connect Error ' . $connection -> connect_error);
	}

	$quantity = $_GET['quantity'];
	$item_id = $_GET['item_id'];
	$delivery = "Shipping";
	$date = date('Y-m-d H:i:s');
	$tot_amount = 40 - $quantity;
	//assuming the total amount of each product the company has is 40. And assuming the quantity entered by the user is always less than 40.

	$sql3 = "SELECT ITEM_ID FROM orders WHERE ITEM_ID='$item_id'";

	$res3 = $connection -> query($sql3);

	$row3 = $res3 -> fetch_assoc();

	if($row3 == NULL){
		$sql = "INSERT INTO orders(ITEM_ID,QUANTITY, TOT_AMOUNT, ORDER_DATE, DELIVERY_METHOD) VALUES ('$item_id', '$quantity', '$tot_amount' , '$date', '$delivery');";

		$res = $connection -> query($sql);

		if($res){
				print("<p>Order was inserted successfully!</p>");
		}
		else{
			print("<p>Order not inserted.</p>");
		}
	}
	else{
			$sql2 = "UPDATE orders SET QUANTITY = $quantity, TOT_AMOUNT = $tot_amount WHERE ITEM_ID = $item_id";
			$res2 = $connection -> query($sql2);

			if($res2 == true){
				print("<p>Order was updated successfully!</p>");
			}
			else{
				print("<p>Order was not updated.</p>");
			}
		}

	$connection -> close();
	
?>

</body>
</html>