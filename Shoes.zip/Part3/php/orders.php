<html>
<head>
	<title>Subscribe</title>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="../css/website.css">
	<link href="../css/mobile.css" rel="stylesheet" media="only screen and (max-width: 700px)" />
	<link href="../css/website.css" rel="stylesheet" media="screen and (min-width: 701px)" />
	<link href="../css/print.css" rel="stylesheet" media="print"/>
	
<title>Products</title>
<style type="text/css">
 table, td, th{
 	border: solid black 1px;
 	border-collapse: collapse;
 }
</style>
</head>
<body style="text-align: center;">

	<header class="topnav">
	<img src = "../images/logo.png" width = "80px">
	  <a href = "../html/home.html">Home</a>
	  <a href = "products.php">Products</a>
	  <a class="active">Orders</a>
	  <a href = "../html/subscribe.html">Subscribe</a>
	  <a href = "../html/login.html">Log in</a>
	  <a>Log out</a>
	</header>

	<div style = "padding-top: 70px;"></div>

	
<?php
	$server = "localhost";
	$user = "60095068";
	$password = "aarizsyed";
	$database = "db60095068";

	$connection = new mysqli($server, $user, $password, $database);

	if($connection -> connect_error){
		die('Connect Error ' . $connection -> connect_error);
	}

	$sql = "SELECT * FROM orders";
	$res = $connection -> query($sql);

	if($res -> num_rows == 0){
		print("<p>No orders found</p>");
	}
	else{
		print("<table>");
		print("<tr><th>ORDER ID</th><th>ITEM ID</th><th>QUANTITY</th><th>TOTAL AMOUNT</th><th>ORDER_DATE</th><th>DELIVERY METHOD</th></tr>");
		while($row = $res -> fetch_assoc()){
			print("<tr>");
			print("<td>" . $row['ORDERS_ID'] . "</td>");
			print("<td>" . $row['ITEM_ID'] . "</td>");
			print("<td>" . $row['QUANTITY'] . "</td>");
			print("<td>" . $row['TOT_AMOUNT'] . "</td>");
			print("<td>" . $row['ORDER_DATE'] . "</td>");
			print("<td>" . $row['DELIVERY_METHOD'] . "</td>");
			print("</tr>");
		}
			print("</table>");
	}
?>

</body>
</html>
