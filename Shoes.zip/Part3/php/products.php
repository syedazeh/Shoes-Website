<html>
<head>
	<title>Subscribe</title>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="../css/website.css">
	<link href="../css/mobile.css" rel="stylesheet" media="only screen and (max-width: 700px)" />
	<link href="../css/website.css" rel="stylesheet" media="screen and (min-width: 701px)" />
	<link href="../css/print.css" rel="stylesheet" media="print"/>
	
<title>Products</title>
<style type="text/css">
 table, td, th{
 	border: solid black 1px;
 	border-collapse: collapse;
 }
</style>
</head>
<body style="text-align: center;">

	<header class="topnav">
	<img src = "../images/logo.png" width = "80px">
	  <a href = "../html/home.html">Home</a>
	  <a class="active">Products</a>
	  <a href = "orders.php">Orders</a>
	  <a href = "../html/subscribe.html">Subscribe</a>
	  <a href = "../html/login.html">Log in</a>
	  <a>Log out</a>
	</header>

	<div style = "padding-top: 70px;"></div>

	
<?php
	$server = "localhost";
	$user = "60095068";
	$password = "aarizsyed";
	$database = "db60095068";

	$connection = new mysqli($server, $user, $password, $database);

	if($connection -> connect_error){
		die('Connect Error ' . $connection -> connect_error);
	}

	$sql = "SELECT * FROM item";
	$res = $connection -> query($sql);

	if($res -> num_rows == 0){
		print("<p>No orders found</p>");
	}

	else{
		print("<table><tr><th>Name</th><th>Price</th><th>Submit</th>");
		while($row = $res -> fetch_assoc()){
			print("<tr><td>" . $row['ITEM_NAME'] . "</td>");
			print("<td>" . $row['ITEM_PRICE'] . "</td>");
			print("<td>");
			print("<form action = 'details.php' method = 'GET'>");
			print("<input type = submit value=Submit>");
			print("<input type = 'hidden' name = 'item_id' value = '" . $row['ITEM_ID'] . "'>");
			print("</form>");
			print("</td>");
			print("</tr>");
		}
		print("</table>");
	}
?>

</body>
</html>