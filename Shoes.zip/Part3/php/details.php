<html>
<head>
<style type="text/css">
 table, td, th{
 	border: solid black 1px;
 	border-collapse: collapse;
 }
</style>
</head>
<body>

<?php
	$server = "localhost";
	$user = "60095068";
	$password = "aarizsyed";
	$database = "db60095068";

	$connection = new mysqli($server, $user, $password, $database);

	if($connection -> connect_error){
		die('Connect Error ' . $connection -> connect_error);
	}

	$item_id = $_GET['item_id'];

	$sql = "SELECT * FROM item WHERE ITEM_ID = '$item_id'";
	$res = $connection -> query($sql);

	if($res -> num_rows == 0){
		print("<p>No orders found</p>");
	}
	else{
	print("<table>");
	print("<tr><th>ITEM ID</th>
		<th>ITEM NAME</th>
		<th>ITEM PRICE</th>
		<th>ITEM DESCRIPTION</th>
		<th>ITEM IMAGE NAME</th>
		<th>QUANTITY</th>
		<th>SUBMIT</th></tr>");
	while($row = $res -> fetch_assoc()){
		print("<tr>");
		print("<td>" . $row['ITEM_ID'] . "</td>");
		print("<td>" . $row['ITEM_NAME'] . "</td>");
		print("<td>" . $row['ITEM_PRICE'] . "</td>");
		print("<td>" . $row['ITEM_DESC'] . "</td>");
		print("<td>" . $row['ITEM_IMAGE_NAME'] . "</td>");
		print("<td>");
		print("<form action = 'purchase.php' method = 'GET'>");
		print("<input type = 'number' name = 'quantity'/>");
		print("</td>");
		print("<td>");
		print("<input type = 'submit' value = 'Submit quantity'>");
		print("<input type = 'hidden' name = 'item_id' value = '" . $row['ITEM_ID'] . "'>");
		print("</form>");
		print("</td>");
		print("</tr>");
	}
	print("</table>");
}
?>

</body>
</html>