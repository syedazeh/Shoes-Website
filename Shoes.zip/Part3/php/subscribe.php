<?php
	$server = "localhost";
	$user = "60095068";
	$password = "aarizsyed";
	$database = "db60095068";

	$connection = new mysqli($server, $user, $password, $database);

	if($connection -> connect_error){
		die('Connect Error ' . $connection -> connect_error);
	}

	$username = $_GET['user_name'];
	$pass = $_GET['password'];
	$confirm = $_GET['confirm'];
	$email = $_GET['email'];
	$bldg = $_GET['bldg'];
	$street = $_GET['street'];
	$number = $_GET['number'];

	if(isset($_GET['submit'])){
		$cities = $_GET['cities'];
		if($cities == 'doha'){
			$city = "doha";
		}
		elseif ($cities == 'lusail') {
			$city = "lusail";
		}
		elseif ($cities == 'wakra') {
			$city = "wakra";
		}
		elseif ($cities == 'khor') {
			$city = "khor";
		}
		elseif ($cities == 'hilal') {
			$city = "hilal";
		}
		else{
			$city = "madinat";
		}
	}
	
	if(isset($_GET['option'])){
		$option = $_GET['option'];
		if($option == 'phone'){
			$selected = "phone call";
		}
		elseif ($option == 'emailid') {
			$selected = "email";
		}
		else{
			$selected = "sms message";
		}
	}

	$sql = "INSERT INTO customer(CUS_NAME, CUS_PASSWORD, CUS_EMAIL, CUS_BLDG, CUS_STREET, CUS_PHONE, CUS_CONTACT, CUS_CITY) VALUES ('$username' , '$pass' , '$email' , '$bldg' , '$street', '$number', '$selected', '$city');";

	$res = $connection -> query($sql);

	if($res){
		print("<p>Registration completed successfully.</p>");
		header('Location: ../html/login.html');
	}
		else{
			print("<p>Registration failed!</p>");
			print("<a href = '../html/subscribe.html'>Click here to go back to the subscription page!</a>");
		}

	$connection -> close();

?>